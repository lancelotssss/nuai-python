import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertCircle,
  BriefcaseBusiness,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  FileText,
  LayoutDashboard,
  Loader2,
  LogOut,
  ShieldCheck,
  UsersRound,
} from "lucide-react";

import PageTitle from "../../components/PageTitle";
import RequirementGate from "../public/RequirementGate.jsx";
import AlumniTransitionGate from "./AlumniTransitionGate.jsx";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  import.meta.env.VITE_API_URL ||
  "http://127.0.0.1:8000/api";

const BRAND_BLUE = "#3D398C";

function safe(value) {
  return String(value ?? "").trim();
}

function norm(value) {
  return safe(value).toLowerCase();
}

function normalizeRole(value) {
  return norm(value).replace(/[\s_]+/g, "-");
}

function normalizeListResponse(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.results)) return data.results;
  return [];
}

function getStoredAccount() {
  try {
    return JSON.parse(localStorage.getItem("nuai_account") || "null");
  } catch {
    return null;
  }
}

async function apiRequest(endpoint, options = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    const message =
      data?.message ||
      data?.detail ||
      Object.values(data || {})?.flat?.()?.[0] ||
      "Request failed.";

    throw new Error(String(message));
  }

  return data;
}

function getInternNuEmail(row = {}) {
  return safe(
    row.nu_email ||
      row.nuEmail ||
      row.email ||
      row.contactInformation?.nuEmail ||
      row.contactInformation?.nu_email,
  );
}

function getInternPersonalEmail(row = {}) {
  return safe(
    row.personal_email ||
      row.personalEmail ||
      row.contactInformation?.personalEmail ||
      row.contactInformation?.personal_email,
  );
}

function getInternContactNumber(row = {}) {
  return safe(
    row.contact_number ||
      row.contactNumber ||
      row.contactInformation?.contactNumber ||
      row.contactInformation?.contact_number,
  );
}

function getInternName(row = {}) {
  const fullName = safe(row.full_name || row.fullName || row.name);

  if (fullName) return fullName;

  return [
    row.first_name || row.firstName,
    row.middle_name || row.middleName,
    row.last_name || row.lastName,
  ]
    .map(safe)
    .filter(Boolean)
    .join(" ");
}

function getAccountLoginEmail(account = {}) {
  return safe(account.email || account.login_email || account.loginEmail);
}

function getAccountNuEmail(account = {}) {
  return safe(account.nu_email || account.nuEmail || account.email);
}

function internMatchesLoggedInAccount(intern = {}, account = {}) {
  const loginEmail = norm(getAccountLoginEmail(account));
  const accountNuEmail = norm(getAccountNuEmail(account));
  const internNuEmail = norm(getInternNuEmail(intern));
  const internPersonalEmail = norm(getInternPersonalEmail(intern));

  if (!internNuEmail && !internPersonalEmail) return false;

  /*
    Important:
    - While the user is Intern, login is NU email.
    - After transition, login becomes personal email.
    - NU email and personal email must stay separate.
  */
  return (
    (internNuEmail && internNuEmail === loginEmail) ||
    (internNuEmail && internNuEmail === accountNuEmail) ||
    (internPersonalEmail && internPersonalEmail === loginEmail)
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  description,
  accent = BRAND_BLUE,
}) {
  return (
    <Card className="border-border/60 bg-white shadow-sm">
      <CardContent className="px-5 py-4">
        <div className="flex items-center gap-4">
          <div
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${accent}1A` }}
          >
            <Icon className="h-5 w-5" style={{ color: accent }} />
          </div>

          <div className="space-y-0.5">
            <p
              className="text-xl font-bold leading-tight tracking-tight"
              style={{ color: accent }}
            >
              {value}
            </p>
            <p className="text-xs font-semibold text-foreground/80">{label}</p>
            <p className="text-[10px] text-muted-foreground">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function QuickActionCard({ icon: Icon, title, description, onClick }) {
  return (
    <Card
      className="group cursor-pointer border-border/50 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#3D398C]/20 hover:shadow-md"
      onClick={onClick}
    >
      <CardContent className="px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#3D398C]/5 text-[#3D398C] transition-colors group-hover:bg-[#3D398C]/10">
            <Icon size={18} />
          </div>

          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-semibold text-foreground">
              {title}
            </p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-muted-foreground">
              {description}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SessionExpiredCard({ onLogin }) {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 px-6">
      <Card className="w-full max-w-md border-border bg-white shadow-sm">
        <CardContent className="p-6 text-center">
          <AlertCircle className="mx-auto h-10 w-10 text-red-500" />
          <h1 className="mt-4 text-lg font-bold text-foreground">
            Session expired
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Please log in again to continue.
          </p>
          <Button
            className="mt-5 bg-[#3D398C] text-white hover:bg-[#312d73]"
            onClick={onLogin}
          >
            Go to Login
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}

function LoadingGate() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 px-6">
      <div className="flex flex-col items-center gap-3 text-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#3D398C]" />
        <div>
          <p className="text-sm font-semibold text-foreground">
            Checking intern profile...
          </p>
          <p className="text-xs text-muted-foreground">
            Please wait while we prepare your dashboard.
          </p>
        </div>
      </div>
    </main>
  );
}

function GateErrorCard({ message, onRetry, onLogout }) {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 px-6">
      <Card className="w-full max-w-md border-red-200 bg-white shadow-sm">
        <CardContent className="p-6 text-center">
          <AlertCircle className="mx-auto h-10 w-10 text-red-500" />
          <h1 className="mt-4 text-lg font-bold text-foreground">
            Unable to continue
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">{message}</p>
          <div className="mt-5 flex justify-center gap-2">
            <Button variant="outline" onClick={onRetry}>
              Retry
            </Button>
            <Button
              className="bg-[#3D398C] text-white hover:bg-[#312d73]"
              onClick={onLogout}
            >
              Logout
            </Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

function AlreadyTransitionedCard({ internRecord, account, onLogout }) {
  const personalEmail =
    getInternPersonalEmail(internRecord) || getAccountLoginEmail(account);

  return (
    <>
      <PageTitle title="Alumni Transition Complete | NUAI" />

      <main className="grid min-h-screen place-items-center bg-slate-50 px-6">
        <Card className="w-full max-w-md border-emerald-200 bg-white shadow-sm">
          <CardContent className="p-6 text-center">
            <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-600" />

            <h1 className="mt-4 text-lg font-bold text-foreground">
              Account already transitioned
            </h1>

            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Your account has already transitioned to Alumni. Please log in
              again using your personal email.
            </p>

            <div className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3 text-left">
              <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">
                Alumni Login Email
              </p>
              <p className="mt-1 break-all text-sm font-bold text-emerald-800">
                {personalEmail || "Your personal email"}
              </p>
            </div>

            <Button
              className="mt-5 w-full bg-[#3D398C] text-white hover:bg-[#312d73]"
              onClick={onLogout}
            >
              Go to Login
            </Button>
          </CardContent>
        </Card>
      </main>
    </>
  );
}

export default function AlumniDashboardPage() {
  const navigate = useNavigate();

  const [account, setAccount] = useState(() => getStoredAccount());
  const [internRecord, setInternRecord] = useState(null);
  const [gateLoading, setGateLoading] = useState(true);
  const [gateError, setGateError] = useState("");

  const role = normalizeRole(account?.role);
  const isIntern = role === "intern";
  const isAlumni = role === "alumni";
  const roleLabel = isIntern ? "Intern" : "Alumni";
  const userEmail = getAccountLoginEmail(account) || "—";

  const internStatus = norm(internRecord?.status);

  const isInternTransitioning =
    isIntern && internRecord && internStatus === "transitioning";

  const isInternAlreadyTransitioned =
    isIntern &&
    internRecord &&
    (internStatus === "transitioned" || internStatus === "alumni");

  const needsInternRequirementGate =
    isIntern &&
    internRecord &&
    internStatus !== "transitioning" &&
    internStatus !== "transitioned" &&
    (!getInternContactNumber(internRecord) ||
      !getInternPersonalEmail(internRecord));

  const loadInternRecord = useCallback(async () => {
    if (!account) {
      setGateLoading(false);
      return;
    }

    if (!isIntern) {
      setGateLoading(false);
      return;
    }

    if (!getAccountLoginEmail(account)) {
      setGateError("Unable to identify your intern account. Please log in again.");
      setGateLoading(false);
      return;
    }

    setGateLoading(true);
    setGateError("");

    try {
      const internsData = await apiRequest("/interns/");
      const interns = normalizeListResponse(internsData);

      const match = interns.find((item) =>
        internMatchesLoggedInAccount(item, account),
      );

      if (!match) {
        setGateError(
          "No intern profile was found for this account. If your account already transitioned, please log in using your personal email.",
        );
        setInternRecord(null);
        return;
      }

      setInternRecord(match);
    } catch (error) {
      setGateError(error?.message || "Unable to load your intern profile.");
      setInternRecord(null);
    } finally {
      setGateLoading(false);
    }
  }, [account, isIntern]);

  useEffect(() => {
    loadInternRecord();
  }, [loadInternRecord]);

  function handleLogout() {
    localStorage.removeItem("nuai_account");
    setAccount(null);
    navigate("/login", { replace: true });
  }

  function handleRequirementCompleted(updatedIntern) {
    setInternRecord(updatedIntern);
  }

  function handleTransitionCompleted() {
    localStorage.removeItem("nuai_account");
    setAccount(null);
    navigate("/login", { replace: true });
  }

  if (!account) {
    return <SessionExpiredCard onLogin={handleLogout} />;
  }

  if (isIntern && gateLoading) {
    return <LoadingGate />;
  }

  if (isIntern && gateError) {
    return (
      <GateErrorCard
        message={gateError}
        onRetry={loadInternRecord}
        onLogout={handleLogout}
      />
    );
  }

  if (isInternAlreadyTransitioned) {
    return (
      <AlreadyTransitionedCard
        internRecord={internRecord}
        account={account}
        onLogout={handleLogout}
      />
    );
  }

  /*
    Correct order:
    1. If the exact logged-in intern is transitioning, show AlumniTransitionGate.
    2. Else, if intern details are missing, show RequirementGate.
    3. Else, show dashboard.
  */
  if (isInternTransitioning) {
    return (
      <AlumniTransitionGate
        intern={internRecord}
        account={account}
        onCompleted={handleTransitionCompleted}
        onBack={handleLogout}
      />
    );
  }

  if (needsInternRequirementGate) {
    return (
      <RequirementGate
        account={account}
        internRecord={internRecord}
        onCompleted={handleRequirementCompleted}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <>
      <PageTitle title={`${roleLabel} Dashboard | NUAI`} />

      <main className="min-h-screen bg-slate-50">
        <header className="border-b border-border bg-white">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#F5DA3E]">
                NUAI
              </p>

              <h1 className="mt-1 text-2xl font-bold text-[#3D398C]">
                {roleLabel} Dashboard
              </h1>

              <p className="mt-1 text-sm text-muted-foreground">
                Access services, jobs, surveys, announcements, and profile tools.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Badge
                variant="outline"
                className="border-[#3D398C]/20 text-[#3D398C]"
              >
                {roleLabel}
              </Badge>

              <Button
                type="button"
                onClick={handleLogout}
                variant="outline"
                className="border-border text-red-600 hover:bg-red-50 hover:text-red-700"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </header>

        <section className="mx-auto max-w-7xl space-y-6 px-6 py-8">
          <Card className="overflow-hidden border-border/60 border-l-[#3D398C] shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-foreground">
                    Welcome,{" "}
                    <span className="text-[#3D398C]">{roleLabel}!</span>{" "}
                    <span className="text-xs font-light text-[#b1b1b1]">
                      ({userEmail})
                    </span>
                  </h2>

                  <p className="mt-1 text-sm text-muted-foreground">
                    Welcome to your {isIntern ? "intern" : "alumni"} portal.
                  </p>

                  {isIntern && internRecord ? (
                    <div className="mt-3 grid gap-1 text-xs text-muted-foreground">
                      <p>
                        NU Email:{" "}
                        <span className="font-semibold text-[#3D398C]">
                          {getInternNuEmail(internRecord) || "—"}
                        </span>
                      </p>
                      <p>
                        Personal Email:{" "}
                        <span className="font-semibold text-[#3D398C]">
                          {getInternPersonalEmail(internRecord) || "—"}
                        </span>
                      </p>
                    </div>
                  ) : null}
                </div>

                <Badge
                  variant="outline"
                  className="shrink-0 border-[#F5DA3E]/50 bg-[#F5DA3E]/10 text-[11px] font-semibold text-[#3D398C]"
                >
                  {roleLabel}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              icon={UsersRound}
              label="Records"
              value="Ready"
              description="Role workspace is available"
            />
            <StatCard
              icon={ClipboardList}
              label="Tasks"
              value="Active"
              accent="#059669"
              description="Dashboard modules are prepared"
            />
            <StatCard
              icon={BriefcaseBusiness}
              label="Services"
              value="Open"
              accent="#D97706"
              description="Role-based services connected soon"
            />
            <StatCard
              icon={ShieldCheck}
              label="Access"
              value="Verified"
              accent="#7C3AED"
              description="Django role-based login"
            />
          </div>

          <div>
            <div className="mb-3">
              <h2 className="text-sm font-semibold text-foreground">
                Quick Actions
              </h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Jump to frequently used sections
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <QuickActionCard
                icon={LayoutDashboard}
                title="Dashboard Overview"
                description="View your role-based dashboard overview"
                onClick={() => {}}
              />
              <QuickActionCard
                icon={FileText}
                title="Records"
                description="Open and manage role-specific records"
                onClick={() => {}}
              />
              <QuickActionCard
                icon={CalendarDays}
                title="Activities"
                description="Review updates and activities"
                onClick={() => {}}
              />
            </div>
          </div>

          {isAlumni ? (
            <Card className="border-border/60 bg-white shadow-sm">
              <CardContent className="p-5">
                <h2 className="text-sm font-semibold text-foreground">
                  Alumni Access
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  You are logged in as Alumni using your personal email.
                </p>
              </CardContent>
            </Card>
          ) : null}
        </section>
      </main>
    </>
  );
}